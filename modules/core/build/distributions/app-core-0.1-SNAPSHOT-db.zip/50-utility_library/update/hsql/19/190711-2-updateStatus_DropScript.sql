alter table UTILITYLIBRARY_STATUS drop column USER_ID__U99237 cascade ;
