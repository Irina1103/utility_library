alter table SEC_USER add column STATUS varchar(100) ;
alter table SEC_USER add column DTYPE varchar(100) ;
