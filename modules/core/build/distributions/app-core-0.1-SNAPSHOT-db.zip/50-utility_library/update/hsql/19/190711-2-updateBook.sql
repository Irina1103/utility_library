alter table UTILITYLIBRARY_BOOK add column PLACE_PUBLICATION varchar(255) ;
